/*

🌟 DILARANG HAPUS WM INI 🌟
  - Ini adalah script franki, jika ingin menghapus wm ini silahkan order pt sc ke franki agar bebas rename sc
  - jika tetap menghapus maka kamu akan terkena hak cipta dan tidak akan dapat mengakses script ini
  - Dilarang memperjual belikan sc ini, jika ketauan maka terkena denda Rp 500.000, jika tidak di tebus siap siap akan diblacklist dari semua group bot WhatsApp dan Hosting dan siap siap Hytam dan Viral nomor lu
  
💖 Terima kasih telah menghargai karya kami! 💖

╭━━┳━┳━━┳━┳┳┳┳━━╮
┃━┳┫╋┃╭╮┃┃┃┃╭┻┃┃╯
┃╭╯┃╮┫┣┫┃┃┃┃╰┳┃┃╮
╰╯╱╰┻┻╯╰┻┻━┻┻┻━━╯

CONTACT DEVELOPER JIKA INGIN MEMBELI NO ENC
  -  WHATSAPP: wa.me/6285136472024
  -  TELEGRAM: https://t.me/xjsjkakajsi
  -  DISCORD: https://discord.gg/5eWnt9jk
  -  YOUTUBE: https://youtube.com/@zfranzxoffc?si=LGafElhuKGkLd4Kf
  -  INSTAGRAM: https://www.instagram.com/zfranzxkaciw_?igsh=MXNxNzV1cTJ6YTBobw==
  
  - ADA KELUHAN ATAU SCRIPT ERROR BISA HUBUNGI FRANKI SEGERA. 
  
  
•• DEVELOPER SCRIPT INI 
• FRANKI
• SOLO PLAYER

*/

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

// Setting Onwer & Bot
global.linkOwner = "https://wa.me/6287780981237"
global.owner = '6287780981237@s.whatsapp.net'
global.ownerbot = '6287780981237'
global.storename = 'FRANKI STORE'
global.versi = version
global.namaOwner = "Franki"
global.packname = 'Franki'
global.botname = 'Kine Cpanel'
global.botname2 = 'Kine Cpanel'

// Setting Panel
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://kyamik.asymodss.my.id"
global.apikey = "ptla_LMgRF4V8z1nY6xOyEzwUh2sAGhM6W9Gnv1Q4W9lPK7T" //ptla
global.capikey = "ptlc_qZ6XWqo2vmMgiSuygOqCtQ9oOJOccVtle28bSWoNHvA" //ptlc

//Setting Payment
global.dana = "085363921814" /*OPSIONAL!!*/
global.gopay = "-" /*OPSIONAL!!*/
global.qris = "https://files.catbox.moe/mjdmod.jpg"

// Setting Thumbnail
global.image = "https://i.supa.codes/AbWC3z"
global.mp4 = "https://i.supa.codes/iVhzmw"

// Setting Saluran
global.linkgc = "https://chat.whatsapp.com/FMbIi6sjFZcIrqpJcLBCge"
global.linkSaluran = "https://whatsapp.com/channel/0029VaeRxEf0wajqtfKA1o1J"
global.idSaluran = "120363299117018597@newsletter"
global.namaSaluran = "Franki"
global.website = "https://tinyurl.com/produkfranki"

global.mess = {
	owner: "khusus owner kine",
	admin: "khusus admin",
	botAdmin: "jadiin bot admin dulu baru bisa!",
	group: "khusus group",
	private: "khusus chat pribadi ",
	prem: "khusus premium",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})