/*

🌟 DILARANG HAPUS WM INI 🌟
  - Ini adalah script franki, jika ingin menghapus wm ini silahkan order pt sc ke franki agar bebas rename sc
  - jika tetap menghapus maka kamu akan terkena hak cipta dan tidak akan dapat mengakses script ini
  - Dilarang memperjual belikan sc ini, jika ketauan maka terkena denda Rp 500.000, jika tidak di tebus siap siap akan diblacklist dari semua group bot WhatsApp dan Hosting dan siap siap Hytam dan Viral nomor lu
  
💖 Terima kasih telah menghargai karya kami! 💖

╭━━┳━┳━━┳━┳┳┳┳━━╮
┃━┳┫╋┃╭╮┃┃┃┃╭┻┃┃╯
┃╭╯┃╮┫┣┫┃┃┃┃╰┳┃┃╮
╰╯╱╰┻┻╯╰┻┻━┻┻┻━━╯

CONTACT DEVELOPER JIKA INGIN MEMBELI NO ENC
  -  WHATSAPP: wa.me/6285136472024
  -  TELEGRAM: https://t.me/xjsjkakajsi
  -  DISCORD: https://discord.gg/5eWnt9jk
  -  YOUTUBE: https://youtube.com/@zfranzxoffc?si=LGafElhuKGkLd4Kf
  -  INSTAGRAM: https://www.instagram.com/zfranzxkaciw_?igsh=MXNxNzV1cTJ6YTBobw==
  
  - ADA KELUHAN ATAU SCRIPT ERROR BISA HUBUNGI FRANKI SEGERA. 
  
  
•• DEVELOPER SCRIPT INI 
• FRANKI
• SOLO PLAYER

*/

const canvafy = require("canvafy")

async function promoteBanner(avatar, name, type) {
    const title = name
    const desc = type == "promote" ? "Telah menjadi admin" : "Telah di berhentikan menjadi admin"
    const background = "https://img101.pixhost.to/images/642/557922982_skyzopedia.jpg"
    const welcome = await new canvafy.WelcomeLeave()
    .setAvatar(avatar)
    .setBackground("image", background)
    .setTitle(title.length > 20 ? (title.substring(0, 16) + "..") : title)
    .setDescription(desc.length > 70 ? (desc.substring(0, 65) + "..") : desc)
    .setBorder("#2a2e35")
    .setAvatarBorder("#2a2e35")
    .setOverlayOpacity(0.1)
    .build()
    return welcome
}

module.exports = { promoteBanner }
      
